const axios = require('axios'); // Need to install axios: npm install axios
const jwt = require('jsonwebtoken'); // Assuming this is needed for token generation/verification
const Admin = require('./models/admin.model'); // Adjust path as needed
const bcrypt = require('bcrypt'); // For password hashing if needed

const services = [
    { name: 'Plumber', description: 'Expert plumbing services for your home or office.', image: 'https://img.icons8.com/fluency/80/000000/plumbing.png' },
    { name: 'Electrician', description: 'Certified electricians for all your wiring and repair needs.', image: 'https://img.icons8.com/fluency/80/000000/electrical-safety.png' },
    { name: 'Carpenter', description: 'Skilled carpentry for custom furniture, repairs, and installations.', image: 'https://img.icons8.com/fluency/80/000000/carpenter.png' },
    { name: 'Mechanic', description: 'Professional car repair and maintenance services.', image: 'https://img.icons8.com/fluency/80/000000/car-service.png' },
    { name: 'Gardener', description: 'Experienced gardeners for lawn care, landscaping, and plant maintenance.', image: 'https://img.icons8.com/fluency/80/000000/gardening.png' },
    { name: 'Cleaner', description: 'Thorough cleaning services for residential and commercial spaces.', image: 'https://img.icons8.com/fluency/80/000000/cleaning-service.png' },
    { name: 'Painter', description: 'Professional painting services for interiors and exteriors.', image: 'https://img.icons8.com/fluency/80/000000/paint-roller.png' },
    { name: 'Appliance Repair', description: 'Repair services for all major home appliances.', image: 'https://img.icons8.com/fluency/80/000000/maintenance.png' },
    { name: 'IT Support', description: 'Technical assistance for computers, networks, and software.', image: 'https://img.icons8.com/fluency/80/000000/software-engineer.png' },
    { name: 'Tutor', description: 'Personalized tutoring in various subjects for all ages.', image: 'https://img.icons8.com/fluency/80/000000/teacher.png' },
    { name: 'Pest Control', description: 'Effective solutions for rodent and insect infestations.', image: 'https://img.icons8.com/fluency/80/000000/pest-control.png' },
    { name: 'Locksmith', description: 'Reliable locksmith services for homes, businesses, and vehicles.', image: 'https://img.icons8.com/fluency/80/000000/door-key.png' },
    { name: 'Mover', description: 'Efficient and careful moving services for local and long-distance.', image: 'https://img.icons8.com/fluency/80/000000/moving.png' },
    { name: 'Pet Sitter', description: 'Trustworthy pet sitting and dog walking services.', image: 'https://img.icons8.com/fluency/80/000000/dog.png' },
    { name: 'Massage Therapist', description: 'Relaxing and therapeutic massage services.', image: 'https://img.icons8.com/fluency/80/000000/massage.png' },
    { name: 'Photographer', description: 'Professional photography for events, portraits, and commercial needs.', image: 'https://img.icons8.com/fluency/80/000000/camera.png' },
    { name: 'Cleaner', description: 'Professional cleaning services for homes and offices.', image: 'https://img.icons8.com/fluency/80/000000/cleaning-service.png' },
    { name: 'Personal Trainer', description: 'Customized fitness programs and personal training sessions.', image: 'https://img.icons8.com/fluency/80/000000/personal-trainer.png' },
    { name: 'Web Developer', description: 'Building and maintaining modern websites and web applications.', image: 'https://img.icons8.com/fluency/80/000000/web-design.png' },
    { name: 'Graphic Designer', description: 'Creative design solutions for logos, branding, and marketing materials.', image: 'https://img.icons8.com/fluency/80/000000/paint-palette.png' }
];

const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASSWORD = 'admin';
const JWT_SECRET = 'MyProject2026SecureKey'; // Must match the one in admin.controller.js

async function seedServices() {
    try {
        // Step 1: Login as admin to get a token
        console.log('Attempting to log in as admin...');
        const loginResponse = await axios.post('http://localhost:3000/api/admin/login', {
            email: ADMIN_EMAIL,
            password: ADMIN_PASSWORD
        });

        const adminToken = loginResponse.data.accessToken;
        console.log('Admin logged in successfully. Token obtained.');

        // Step 2: Add services
        console.log('Adding services...');
        for (const service of services) {
            try {
                const addServiceResponse = await axios.post('http://localhost:3000/api/admin/services', service, {
                    headers: {
                        'Authorization': `Bearer ${adminToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                console.log(`Added service: ${service.name}, ID: ${addServiceResponse.data.id}`);
            } catch (err) {
                console.error(`Failed to add service ${service.name}: ${err.response ? err.response.data.message : err.message}`);
            }
        }
        console.log('Service seeding complete.');

    } catch (error) {
        console.error('Error during service seeding:', error.response ? error.response.data : error.message);
    }
}

// Ensure the server is running before executing this script.
// Also, ensure you have 'axios' installed: npm install axios
// To run: node server/seed_services.js
seedServices();

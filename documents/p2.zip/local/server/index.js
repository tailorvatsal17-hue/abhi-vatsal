const express = require('express');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.send('Welcome to the service booking API!');
});

require("./routes/auth.routes.js")(app);
require("./routes/partner.routes.js")(app);
require("./routes/admin.routes.js")(app);
require("./routes/service.routes.js")(app);
require("./routes/booking.routes.js")(app);
require("./routes/profile.routes.js")(app);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

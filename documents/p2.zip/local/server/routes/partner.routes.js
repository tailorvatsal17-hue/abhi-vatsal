module.exports = app => {
    const router = require('express').Router();
    const partners = require('../controllers/partner.controller.js');
    const { verifyToken } = require('../middleware/authJwt');

    // Public routes (no token required)
    router.post('/signup', partners.signup);
    router.post('/login', partners.login);

    // Protected routes (token required)
    router.use(verifyToken); // All routes below this line will require a token

    // Get partner profile
    router.get('/:id', partners.getProfile);

    // Update partner profile
    router.put('/:id', partners.updateProfile);

    // Accept booking
    router.put('/bookings/:id/accept', partners.acceptBooking);

    // Reject booking
    router.put('/bookings/:id/reject', partners.rejectBooking);

    app.use('/api/partners', router);
};

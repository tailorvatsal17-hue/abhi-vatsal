const sql = require('./db.js');

// constructor
const Partner = function(partner) {
    this.name = partner.name;
    this.email = partner.email;
    this.password = partner.password;
    this.service_id = partner.service_id;
    this.description = partner.description;
    this.profile_image = partner.profile_image;
    this.work_images = partner.work_images;
    this.pricing = partner.pricing;
};

Partner.create = (newPartner, result) => {
    sql.query("INSERT INTO partners SET ?", newPartner, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        console.log("created partner: ", { id: res.insertId, ...newPartner });
        result(null, { id: res.insertId, ...newPartner });
    });
};

Partner.findByEmail = (email, result) => {
    sql.query(`SELECT * FROM partners WHERE email = '${email}'`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length) {
            console.log("found partner: ", res[0]);
            result(null, res[0]);
            return;
        }

        // not found Partner with the email
        result({ kind: "not_found" }, null);
    });
};

Partner.findById = (id, result) => {
    sql.query(`SELECT * FROM partners WHERE id = ${id}`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length) {
            console.log("found partner: ", res[0]);
            result(null, res[0]);
            return;
        }

        // not found Partner with the id
        result({ kind: "not_found" }, null);
    });
};

Partner.updateById = (id, partner, result) => {
    sql.query(
        "UPDATE partners SET name = ?, service_id = ?, description = ?, profile_image = ?, work_images = ?, pricing = ? WHERE id = ?",
        [partner.name, partner.service_id, partner.description, partner.profile_image, partner.work_images, partner.pricing, id],
        (err, res) => {
            if (err) {
                console.log("error: ", err);
                result(null, err);
                return;
            }

            if (res.affectedRows == 0) {
                // not found Partner with the id
                result({ kind: "not_found" }, null);
                return;
            }

            console.log("updated partner: ", { id: id, ...partner });
            result(null, { id: id, ...partner });
        }
    );
};

Partner.updateBookingStatus = (id, status, result) => {
    sql.query(
        "UPDATE bookings SET status = ? WHERE id = ?",
        [status, id],
        (err, res) => {
            if (err) {
                console.log("error: ", err);
                result(null, err);
                return;
            }

            if (res.affectedRows == 0) {
                // not found Booking with the id
                result({ kind: "not_found" }, null);
                return;
            }

            console.log("updated booking status: ", { id: id, status: status });
            result(null, { id: id, status: status });
        }
    );
};

module.exports = Partner;

// For a real application, use environment variables for these settings.
// For this college project, we are hardcoding them for simplicity.
module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "service_booking"
};

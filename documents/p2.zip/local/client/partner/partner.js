document.addEventListener('DOMContentLoaded', () => {
    const partnerLoginForm = document.querySelector('.partner-login-form');
    const partnerSignupForm = document.querySelector('.partner-signup-form');
    const partnerLogoutBtn = document.querySelector('#partner-logout-btn');
    const token = localStorage.getItem('partnerToken');
    const partnerId = localStorage.getItem('partnerId');

    // Redirect to login if not on login/signup page and no token
    if (!token && !window.location.pathname.endsWith('index.html') && !window.location.pathname.endsWith('signup.html')) {
        window.location.href = 'index.html';
    }

    // --- Partner Login ---
    if (partnerLoginForm) {
        partnerLoginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = partnerLoginForm.querySelector('#email').value;
            const password = partnerLoginForm.querySelector('#password').value;

            const response = await fetch('http://localhost:3000/api/partners/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                localStorage.setItem('partnerToken', data.accessToken);
                localStorage.setItem('partnerId', data.id);
                window.location.href = 'dashboard.html';
            } else {
                alert('Login failed: ' + data.message);
            }
        });
    }

    // --- Partner Signup ---
    if (partnerSignupForm) {
        // Fetch services for the dropdown
        fetch('http://localhost:3000/api/services')
            .then(res => res.json())
            .then(services => {
                const serviceSelect = partnerSignupForm.querySelector('#service-id');
                services.forEach(service => {
                    const option = document.createElement('option');
                    option.value = service.id;
                    option.textContent = service.name;
                    serviceSelect.appendChild(option);
                });
            });

        partnerSignupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = partnerSignupForm.querySelector('#name').value;
            const email = partnerSignupForm.querySelector('#email').value;
            const password = partnerSignupForm.querySelector('#password').value;
            const service_id = partnerSignupForm.querySelector('#service-id').value;
            const description = partnerSignupForm.querySelector('#description').value;
            const pricing = partnerSignupForm.querySelector('#pricing').value;

            const response = await fetch('http://localhost:3000/api/partners/signup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password, service_id, description, pricing })
            });

            const data = await response.json();

            if (response.ok) {
                alert('Registration successful! Your account is pending approval by the admin.');
                window.location.href = 'index.html';
            } else {
                alert('Registration failed: ' + data.message);
            }
        });
    }

    // --- Partner Logout ---
    if (partnerLogoutBtn) {
        partnerLogoutBtn.addEventListener('click', () => {
            localStorage.removeItem('partnerToken');
            localStorage.removeItem('partnerId');
            window.location.href = 'index.html';
        });
    }

    // --- Partner Dashboard ---
    if (window.location.pathname.endsWith('dashboard.html')) {
        const headers = { 'Authorization': `Bearer ${token}` };

        // Fetch Total Bookings (Needs partner specific endpoint)
        // For now, fetching all bookings, you'd filter by partnerId on backend
        fetch('http://localhost:3000/api/admin/bookings', { headers }) // This should be a partner-specific endpoint
            .then(res => res.json())
            .then(data => {
                const partnerBookings = data.filter(booking => booking.partner_id == partnerId);
                document.getElementById('total-bookings').textContent = partnerBookings.length;
                document.getElementById('pending-bookings').textContent = partnerBookings.filter(b => b.status === 'Pending').length;
                document.getElementById('completed-bookings').textContent = partnerBookings.filter(b => b.status === 'Completed').length;
                
                // Calculate earnings (placeholder)
                const totalEarnings = partnerBookings.filter(b => b.status === 'Completed').reduce((sum, b) => sum + b.total_cost, 0);
                document.getElementById('total-earnings').textContent = `$${totalEarnings.toFixed(2)}`;

                // Display recent booking requests
                const bookingsTableContainer = document.getElementById('bookings-table');
                let table = '<table><thead><tr><th>ID</th><th>User ID</th><th>Status</th><th>Date</th><th>Time</th><th>Cost</th></tr></thead><tbody>';
                partnerBookings.slice(0, 5).forEach(booking => {
                    table += `<tr>
                        <td>${booking.id}</td>
                        <td>${booking.user_id}</td>
                        <td>${booking.status}</td>
                        <td>${new Date(booking.booking_date).toLocaleDateString()}</td>
                        <td>${booking.booking_time}</td>
                        <td>$${booking.total_cost}</td>
                    </tr>`;
                });
                table += '</tbody></table>';
                bookingsTableContainer.innerHTML = table;
            });
    }

    // --- Partner Bookings Management ---
    if (window.location.pathname.endsWith('bookings.html')) {
        const bookingsTableContainer = document.getElementById('bookings-management-table');
        const statusFilter = document.getElementById('booking-status-filter');
        let allPartnerBookings = [];

        const renderPartnerBookings = (bookings) => {
            let table = '<table><thead><tr><th>Booking ID</th><th>Customer ID</th><th>Service</th><th>Date</th><th>Time</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
            bookings.forEach(booking => {
                table += `<tr>
                    <td>${booking.id}</td>
                    <td>${booking.user_id}</td>
                    <td>${booking.service_id}</td>
                    <td>${new Date(booking.booking_date).toLocaleDateString()}</td>
                    <td>${booking.booking_time}</td>
                    <td>
                        <span class="${booking.status.toLowerCase()}">${booking.status}</span>
                    </td>
                    <td>
                        ${booking.status === 'Pending' ? `
                            <button class="button-success accept-booking-btn" data-id="${booking.id}">Accept</button>
                            <button class="button-danger reject-booking-btn" data-id="${booking.id}">Reject</button>
                        ` : ''}
                    </td>
                </tr>`;
            });
            table += '</tbody></table>';
            bookingsTableContainer.innerHTML = table;

            // Add event listeners for accept/reject buttons
            document.querySelectorAll('.accept-booking-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const bookingId = e.target.dataset.id;
                    fetch(`http://localhost:3000/api/partners/bookings/${bookingId}/accept`, {
                        method: 'PUT',
                        headers: { 'Authorization': `Bearer ${token}` }
                    }).then(res => {
                        if (res.ok) {
                            fetchPartnerBookings(); // Refresh bookings
                            alert('Booking accepted!');
                        } else {
                            alert('Failed to accept booking.');
                        }
                    });
                });
            });

            document.querySelectorAll('.reject-booking-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const bookingId = e.target.dataset.id;
                    fetch(`http://localhost:3000/api/partners/bookings/${bookingId}/reject`, {
                        method: 'PUT',
                        headers: { 'Authorization': `Bearer ${token}` }
                    }).then(res => {
                        if (res.ok) {
                            fetchPartnerBookings(); // Refresh bookings
                            alert('Booking rejected!');
                        } else {
                            alert('Failed to reject booking.');
                        }
                    });
                });
            });
        };

        const fetchPartnerBookings = () => {
            fetch('http://localhost:3000/api/admin/bookings', { headers: { 'Authorization': `Bearer ${token}` } }) // Should be partner specific endpoint
                .then(res => res.json())
                .then(data => {
                    allPartnerBookings = data.filter(booking => booking.partner_id == partnerId);
                    applyPartnerBookingFilters();
                });
        };

        const applyPartnerBookingFilters = () => {
            let filteredBookings = allPartnerBookings;
            const status = statusFilter.value;

            if (status !== 'all') {
                filteredBookings = filteredBookings.filter(b => b.status === status);
            }
            renderPartnerBookings(filteredBookings);
        };

        statusFilter.addEventListener('change', applyPartnerBookingFilters);
        fetchPartnerBookings();
    }

    // --- Partner Profile Management ---
    if (window.location.pathname.endsWith('profile.html')) {
        const profileForm = document.getElementById('partner-profile-form');
        const profileNameInput = document.getElementById('profile-name');
        const profileEmailInput = document.getElementById('profile-email');
        const profileDescriptionInput = document.getElementById('profile-description');
        const profilePricingInput = document.getElementById('profile-pricing');
        const profileImageUrlInput = document.getElementById('profile-image-url');
        const workImagesUrlInput = document.getElementById('work-images-url');

        // Fetch partner profile data
        fetch(`http://localhost:3000/api/partners/${partnerId}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        })
        .then(res => res.json())
        .then(partner => {
            profileNameInput.value = partner.name;
            profileEmailInput.value = partner.email;
            profileDescriptionInput.value = partner.description || '';
            profilePricingInput.value = partner.pricing || '';
            profileImageUrlInput.value = partner.profile_image || '';
            workImagesUrlInput.value = partner.work_images ? partner.work_images.split(',').join(', ') : '';
        });

        // Handle form submission for profile update
        profileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const updatedProfile = {
                name: profileNameInput.value,
                description: profileDescriptionInput.value,
                pricing: profilePricingInput.value,
                profile_image: profileImageUrlInput.value,
                work_images: workImagesUrlInput.value.split(',').map(url => url.trim()).join(',')
            };

            fetch(`http://localhost:3000/api/partners/${partnerId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(updatedProfile)
            })
            .then(res => res.json())
            .then(data => {
                if (data && data.message) {
                    alert(data.message);
                } else {
                    alert('Profile updated successfully!');
                }
            })
            .catch(error => {
                console.error('Error updating profile:', error);
                alert('Failed to update profile.');
            });
        });
    }
});
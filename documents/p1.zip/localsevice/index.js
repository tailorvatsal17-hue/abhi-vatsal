const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');
const connection = require('./src/config/db');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
  secret: 'mysecret',
  resave: false,
  saveUninitialized: true,
}));

app.use('/public', express.static(path.join(__dirname, 'public')));

// Serve HTML files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/login.html'));
});

app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/signup.html'));
});

app.get('/services', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/services.html'));
});

app.get('/providers', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/providers.html'));
});

app.get('/booking', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/booking.html'));
});

app.get('/booking/confirmation', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/booking-confirmation.html'));
});

app.get('/profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/profile.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/index.html'));
});

app.get('/admin/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/dashboard.html'));
});

app.get('/admin/users', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/users.html'));
});

app.get('/admin/users/:userId/bookings', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/user-bookings.html'));
});

app.get('/admin/providers', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/providers.html'));
});

app.get('/admin/services', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/services.html'));
});

app.get('/admin/bookings', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/bookings.html'));
});

app.get('/admin/payments', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/admin/payments.html'));
});

app.get('/partner', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/partner/index.html'));
});

app.get('/partner/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/partner/register.html'));
});

app.get('/partner/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/partner/dashboard.html'));
});

app.get('/partner/bookings', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/partner/bookings.html'));
});

app.get('/partner/profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'src/views/partner/profile.html'));
});

// Routes
const userRoutes = require('./src/routes/userRoutes');
app.use('/api/user', userRoutes);

const adminRoutes = require('./src/routes/adminRoutes');
app.use('/api/admin', adminRoutes);

const partnerRoutes = require('./src/routes/partnerRoutes');
app.use('/api/partner', partnerRoutes);


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/user/profile')
        .then(response => {
            if (!response.ok) {
                window.location.href = '/login';
            }
            return response.json();
        })
        .then(data => {
            const profileDetails = document.getElementById('profile-details');
            profileDetails.innerHTML = `
                <p><strong>Name:</strong> ${data.name}</p>
                <p><strong>Email:</strong> ${data.email}</p>
            `;
        });

    fetch('/api/user/bookings')
        .then(response => response.json())
        .then(data => {
            const bookingHistory = document.getElementById('booking-history');
            if (data.length === 0) {
                bookingHistory.innerHTML = '<p>You have no bookings.</p>';
                return;
            }
            data.forEach(booking => {
                const bookingDiv = document.createElement('div');
                bookingDiv.classList.add('booking');
                bookingDiv.innerHTML = `
                    <p><strong>Booking ID:</strong> ${booking.booking_id}</p>
                    <p><strong>Service:</strong> ${booking.service_name}</p>
                    <p><strong>Provider:</strong> ${booking.partner_name}</p>
                    <p><strong>Date and Time:</strong> ${new Date(booking.booking_time).toLocaleString()}</p>
                    <p><strong>Status:</strong> ${booking.booking_status}</p>
                `;
                bookingHistory.appendChild(bookingDiv);
            });
        });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/user/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/login';
        }
    });
});

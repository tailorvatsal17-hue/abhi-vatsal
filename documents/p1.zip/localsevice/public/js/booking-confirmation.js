document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const bookingId = urlParams.get('id');

    fetch(`/api/user/booking/${bookingId}`)
        .then(response => response.json())
        .then(data => {
            const bookingDetails = document.getElementById('booking-details');
            bookingDetails.innerHTML = `
                <p><strong>Booking ID:</strong> ${data.booking_id}</p>
                <p><strong>Service:</strong> ${data.service_name}</p>
                <p><strong>Provider:</strong> ${data.partner_name}</p>
                <p><strong>Date and Time:</strong> ${new Date(data.booking_time).toLocaleString()}</p>
                <p><strong>Address:</strong> ${data.address}</p>
                <p><strong>Amount:</strong> $${data.amount}</p>
                <p><strong>Booking Status:</strong> ${data.booking_status}</p>
                <p><strong>Payment Status:</strong> ${data.payment_status}</p>
            `;
        });

    document.getElementById('pay-now').addEventListener('click', async () => {
        const response = await fetch('/api/user/payment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ booking_id: bookingId })
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message);
            window.location.reload();
        } else {
            alert(data.message);
        }
    });
});

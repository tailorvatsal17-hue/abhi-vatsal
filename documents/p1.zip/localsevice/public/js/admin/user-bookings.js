document.addEventListener('DOMContentLoaded', () => {
    const bookingsTableBody = document.querySelector('#bookings-table tbody');
    const userName = document.getElementById('user-name');
    const urlParams = new URLSearchParams(window.location.pathname.split('/')[3]);
    const userId = window.location.pathname.split('/')[3];


    fetch(`/api/admin/users/${userId}`)
        .then(response => response.json())
        .then(data => {
            userName.textContent = `Bookings for ${data.name}`;
        });

    fetch(`/api/admin/users/${userId}/bookings`)
        .then(response => {
            if (!response.ok) {
                window.location.href = '/admin';
            }
            return response.json();
        })
        .then(data => {
            bookingsTableBody.innerHTML = '';
            data.forEach(booking => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${booking.booking_id}</td>
                    <td>${booking.service_name}</td>
                    <td>${booking.partner_name}</td>
                    <td>${new Date(booking.booking_time).toLocaleString()}</td>
                    <td>${booking.booking_status}</td>
                `;
                bookingsTableBody.appendChild(row);
            });
        });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

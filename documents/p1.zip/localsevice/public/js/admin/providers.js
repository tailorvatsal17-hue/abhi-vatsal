document.addEventListener('DOMContentLoaded', () => {
    const providersTableBody = document.querySelector('#providers-table tbody');

    const fetchProviders = () => {
        fetch('/api/admin/providers')
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/admin';
                }
                return response.json();
            })
            .then(data => {
                providersTableBody.innerHTML = '';
                data.forEach(provider => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${provider.id}</td>
                        <td>${provider.name}</td>
                        <td>${provider.email}</td>
                        <td>${provider.status}</td>
                        <td>${provider.is_active ? 'Yes' : 'No'}</td>
                        <td>
                            <button class="approve-btn" data-id="${provider.id}" data-status="approved" ${provider.status !== 'pending' ? 'disabled' : ''}>Approve</button>
                            <button class="reject-btn" data-id="${provider.id}" data-status="rejected" ${provider.status !== 'pending' ? 'disabled' : ''}>Reject</button>
                            <button class="toggle-active-btn" data-id="${provider.id}" data-active="${provider.is_active}">
                                ${provider.is_active ? 'Deactivate' : 'Activate'}
                            </button>
                        </td>
                    `;
                    providersTableBody.appendChild(row);
                });
            });
    };

    fetchProviders();

    providersTableBody.addEventListener('click', async (e) => {
        const target = e.target;
        const id = target.dataset.id;

        if (target.classList.contains('approve-btn') || target.classList.contains('reject-btn')) {
            const status = target.dataset.status;
            const response = await fetch(`/api/admin/providers/${id}/approve`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status })
            });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                fetchProviders();
            } else {
                alert(data.message);
            }
        }

        if (target.classList.contains('toggle-active-btn')) {
            const response = await fetch(`/api/admin/providers/${id}/toggle-active`, { method: 'PUT' });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                fetchProviders();
            } else {
                alert(data.message);
            }
        }
    });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

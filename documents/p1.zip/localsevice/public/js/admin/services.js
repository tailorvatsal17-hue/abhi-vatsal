document.addEventListener('DOMContentLoaded', () => {
    const servicesTableBody = document.querySelector('#services-table tbody');
    const addServiceForm = document.getElementById('add-service-form');

    const fetchServices = () => {
        fetch('/api/admin/services')
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/admin';
                }
                return response.json();
            })
            .then(data => {
                servicesTableBody.innerHTML = '';
                data.forEach(service => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${service.id}</td>
                        <td>${service.name}</td>
                        <td>${service.description}</td>
                        <td>${service.base_price}</td>
                        <td>
                            <button class="edit-btn" data-id="${service.id}">Edit</button>
                            <button class="delete-btn" data-id="${service.id}">Delete</button>
                        </td>
                    `;
                    servicesTableBody.appendChild(row);
                });
            });
    };

    fetchServices();

    addServiceForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = e.target.elements.name.value;
        const description = e.target.elements.description.value;
        const base_price = e.target.elements.base_price.value;

        const response = await fetch('/api/admin/services', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, description, base_price })
        });
        const data = await response.json();
        if (response.ok) {
            alert(data.message);
            fetchServices();
            addServiceForm.reset();
        } else {
            alert(data.message);
        }
    });

    servicesTableBody.addEventListener('click', async (e) => {
        const target = e.target;
        const id = target.dataset.id;

        if (target.classList.contains('delete-btn')) {
            const response = await fetch(`/api/admin/services/${id}`, { method: 'DELETE' });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                fetchServices();
            } else {
                alert(data.message);
            }
        }

        if (target.classList.contains('edit-btn')) {
            // In a real application, you would typically open a modal or a separate page for editing.
            // For simplicity, we will just prompt the user for the new values.
            const name = prompt('Enter the new name:');
            const description = prompt('Enter the new description:');
            const base_price = prompt('Enter the new base price:');

            if (name && description && base_price) {
                const response = await fetch(`/api/admin/services/${id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, description, base_price })
                });
                const data = await response.json();
                if (response.ok) {
                    alert(data.message);
                    fetchServices();
                } else {
                    alert(data.message);
                }
            }
        }
    });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

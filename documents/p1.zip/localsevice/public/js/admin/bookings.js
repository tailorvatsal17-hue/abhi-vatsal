document.addEventListener('DOMContentLoaded', () => {
    const bookingsTableBody = document.querySelector('#bookings-table tbody');
    const filterForm = document.getElementById('filter-bookings-form');
    const serviceTypeSelect = document.getElementById('service_type');

    const fetchBookings = (params = '') => {
        fetch(`/api/admin/bookings?${params}`)
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/admin';
                }
                return response.json();
            })
            .then(data => {
                bookingsTableBody.innerHTML = '';
                data.forEach(booking => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${booking.booking_id}</td>
                        <td>${booking.user_name}</td>
                        <td>${booking.partner_name}</td>
                        <td>${booking.service_name}</td>
                        <td>${new Date(booking.booking_time).toLocaleString()}</td>
                        <td>${booking.booking_status}</td>
                        <td>
                            <select class="status-select" data-id="${booking.booking_id}">
                                <option value="pending" ${booking.booking_status === 'pending' ? 'selected' : ''}>Pending</option>
                                <option value="confirmed" ${booking.booking_status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                                <option value="in progress" ${booking.booking_status === 'in progress' ? 'selected' : ''}>In Progress</option>
                                <option value="completed" ${booking.booking_status === 'completed' ? 'selected' : ''}>Completed</option>
                                <option value="cancelled" ${booking.booking_status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                            </select>
                        </td>
                    `;
                    bookingsTableBody.appendChild(row);
                });
            });
    };

    // Fetch service types for the filter dropdown
    fetch('/api/admin/services')
        .then(response => response.json())
        .then(data => {
            data.forEach(service => {
                const option = document.createElement('option');
                option.value = service.id;
                option.textContent = service.name;
                serviceTypeSelect.appendChild(option);
            });
        });

    fetchBookings();

    filterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(filterForm);
        const params = new URLSearchParams(formData).toString();
        fetchBookings(params);
    });

    bookingsTableBody.addEventListener('change', async (e) => {
        if (e.target.classList.contains('status-select')) {
            const bookingId = e.target.dataset.id;
            const status = e.target.value;
            const response = await fetch(`/api/admin/bookings/${bookingId}/status`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status })
            });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                fetchBookings();
            } else {
                alert(data.message);
            }
        }
    });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

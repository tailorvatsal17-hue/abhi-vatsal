document.addEventListener('DOMContentLoaded', () => {
    const paymentsTableBody = document.querySelector('#payments-table tbody');

    const fetchPayments = () => {
        fetch('/api/admin/payments')
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/admin';
                }
                return response.json();
            })
            .then(data => {
                paymentsTableBody.innerHTML = '';
                data.forEach(payment => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${payment.payment_id}</td>
                        <td>${payment.booking_id}</td>
                        <td>${payment.user_name}</td>
                        <td>$${payment.amount}</td>
                        <td>$${payment.commission}</td>
                        <td>${payment.payment_status}</td>
                        <td>${new Date(payment.created_at).toLocaleString()}</td>
                    `;
                    paymentsTableBody.appendChild(row);
                });
            });
    };

    fetchPayments();

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const usersTableBody = document.querySelector('#users-table tbody');

    const fetchUsers = (query = '') => {
        fetch(`/api/admin/users?q=${query}`)
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/admin';
                }
                return response.json();
            })
            .then(data => {
                usersTableBody.innerHTML = '';
                data.forEach(user => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${user.id}</td>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>${user.is_blocked ? 'Yes' : 'No'}</td>
                        <td>
                            <button class="block-btn" data-id="${user.id}" data-blocked="${user.is_blocked}">
                                ${user.is_blocked ? 'Unblock' : 'Block'}
                            </button>
                            <a href="/admin/users/${user.id}/bookings">View Bookings</a>
                        </td>
                    `;
                    usersTableBody.appendChild(row);
                });
            });
    };

    fetchUsers();

    document.getElementById('search-user-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const query = e.target.elements.q.value;
        fetchUsers(query);
    });

    usersTableBody.addEventListener('click', async (e) => {
        if (e.target.classList.contains('block-btn')) {
            const userId = e.target.dataset.id;
            const response = await fetch(`/api/admin/users/${userId}/toggle-block`, { method: 'PUT' });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                fetchUsers();
            } else {
                alert(data.message);
            }
        }
    });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

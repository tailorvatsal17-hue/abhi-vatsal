document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/admin/dashboard')
        .then(response => {
            if (!response.ok) {
                window.location.href = '/admin';
            }
            return response.json();
        })
        .then(data => {
            const dashboardData = document.getElementById('dashboard-data');
            dashboardData.innerHTML = `
                <p><strong>Total Users:</strong> ${data.total_users}</p>
                <p><strong>Total Service Partners:</strong> ${data.total_service_partners}</p>
                <p><strong>Total Services:</strong> ${data.total_services}</p>
                <p><strong>Total Bookings:</strong> ${data.total_bookings}</p>
                <p><strong>Total Earnings:</strong> $${data.total_earnings}</p>
                <h4>Booking Status</h4>
            `;
            data.booking_status.forEach(status => {
                dashboardData.innerHTML += `<p><strong>${status.status}:</strong> ${status.count}</p>`;
            });
        });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/admin/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/admin';
        }
    });
});

document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/api/user/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password })
    });

    const data = await response.json();

    if (response.ok) {
        alert(data.message);
        document.getElementById('signup-form').style.display = 'none';
        document.getElementById('otp-section').style.display = 'block';
        document.getElementById('otp-form').dataset.email = email;
    } else {
        alert(data.message);
    }
});

document.getElementById('otp-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = e.target.dataset.email;
    const otp = document.getElementById('otp').value;

    const response = await fetch('/api/user/verify-otp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, otp })
    });

    const data = await response.json();

    if (response.ok) {
        alert(data.message);
        window.location.href = '/login';
    } else {
        alert(data.message);
    }
});

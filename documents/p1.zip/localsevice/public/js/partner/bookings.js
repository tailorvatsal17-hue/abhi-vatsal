document.addEventListener('DOMContentLoaded', () => {
    const bookingsTableBody = document.querySelector('#bookings-table tbody');

    const fetchBookings = () => {
        fetch('/api/partner/bookings')
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/partner';
                }
                return response.json();
            })
            .then(data => {
                bookingsTableBody.innerHTML = '';
                data.forEach(booking => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${booking.booking_id}</td>
                        <td>${booking.customer_name}</td>
                        <td>${booking.customer_address}</td>
                        <td>${booking.service_name}</td>
                        <td>${new Date(booking.booking_time).toLocaleString()}</td>
                        <td>${booking.status}</td>
                        <td>
                            <button class="accept-btn" data-id="${booking.booking_id}" ${booking.status !== 'pending' ? 'disabled' : ''}>Accept</button>
                            <button class="reject-btn" data-id="${booking.booking_id}" ${booking.status !== 'pending' ? 'disabled' : ''}>Reject</button>
                        </td>
                    `;
                    bookingsTableBody.appendChild(row);
                });
            });
    };

    fetchBookings();

    bookingsTableBody.addEventListener('click', async (e) => {
        const target = e.target;
        const id = target.dataset.id;
        let action = '';

        if (target.classList.contains('accept-btn')) {
            action = 'accept';
        } else if (target.classList.contains('reject-btn')) {
            action = 'reject';
        } else {
            return;
        }

        const response = await fetch(`/api/partner/bookings/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action })
        });
        const data = await response.json();
        if (response.ok) {
            alert(data.message);
            fetchBookings();
        } else {
            alert(data.message);
        }
    });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/partner/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/partner';
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const profileForm = document.getElementById('profile-form');
    const passwordForm = document.getElementById('password-form');
    const portfolioImages = document.getElementById('portfolio-images');
    const addImageForm = document.getElementById('add-image-form');
    const pricingList = document.getElementById('pricing-list');
    const addPricingForm = document.getElementById('add-pricing-form');

    let partnerId;

    const fetchProfile = () => {
        fetch('/api/partner/profile')
            .then(response => {
                if (!response.ok) {
                    window.location.href = '/partner';
                }
                return response.json();
            })
            .then(data => {
                partnerId = data.id;
                profileForm.elements.name.value = data.name;
                profileForm.elements.phone.value = data.phone;
                profileForm.elements.location.value = data.location;
                profileForm.elements.description.value = data.description;
                profileForm.elements.profile_image.value = data.profile_image;
            });
    };

    const fetchPortfolio = () => {
        fetch('/api/partner/portfolio')
            .then(response => response.json())
            .then(data => {
                portfolioImages.innerHTML = '';
                data.forEach(image => {
                    const imageDiv = document.createElement('div');
                    imageDiv.innerHTML = `
                        <img src="${image.image_url}" width="100">
                        <button class="delete-image-btn" data-id="${image.id}">Delete</button>
                    `;
                    portfolioImages.appendChild(imageDiv);
                });
            });
    };

    const fetchPricing = () => {
        fetch('/api/partner/pricing')
            .then(response => response.json())
            .then(data => {
                pricingList.innerHTML = '';
                data.forEach(pricing => {
                    const pricingDiv = document.createElement('div');
                    pricingDiv.innerHTML = `
                        <p><strong>${pricing.service_name}:</strong> $${pricing.price}</p>
                        <button class="delete-pricing-btn" data-id="${pricing.id}">Delete</button>
                    `;
                    pricingList.appendChild(pricingDiv);
                });
            });
    };


    fetchProfile();
    fetchPortfolio();
    fetchPricing();

    profileForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        const response = await fetch('/api/partner/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await response.json();
        alert(result.message);
    });

    passwordForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const password = e.target.elements.password.value;
        const response = await fetch('/api/partner/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password })
        });
        const result = await response.json();
        alert(result.message);
        passwordForm.reset();
    });

    addImageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const image_url = e.target.elements.image_url.value;
        const response = await fetch('/api/partner/portfolio-image', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image_url })
        });
        const result = await response.json();
        alert(result.message);
        addImageForm.reset();
        fetchPortfolio();
    });

    addPricingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const service_name = e.target.elements.service_name.value;
        const price = e.target.elements.price.value;
        const response = await fetch('/api/partner/pricing', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ service_name, price })
        });
        const result = await response.json();
        alert(result.message);
        addPricingForm.reset();
        fetchPricing();
    });

    portfolioImages.addEventListener('click', async (e) => {
        if (e.target.classList.contains('delete-image-btn')) {
            const imageId = e.target.dataset.id;
            const response = await fetch(`/api/partner/portfolio-image/${imageId}`, { method: 'DELETE' });
            const result = await response.json();
            alert(result.message);
            fetchPortfolio();
        }
    });

    pricingList.addEventListener('click', async (e) => {
        if (e.target.classList.contains('delete-pricing-btn')) {
            const pricingId = e.target.dataset.id;
            const response = await fetch(`/api/partner/pricing/${pricingId}`, { method: 'DELETE' });
            const result = await response.json();
            alert(result.message);
            fetchPricing();
        }
    });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/partner/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/partner';
        }
    });
});

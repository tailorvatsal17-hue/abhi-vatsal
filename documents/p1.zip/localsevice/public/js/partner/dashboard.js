document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/partner/dashboard')
        .then(response => {
            if (!response.ok) {
                window.location.href = '/partner';
            }
            return response.json();
        })
        .then(data => {
            const dashboardData = document.getElementById('dashboard-data');
            dashboardData.innerHTML = `
                <p><strong>Total Bookings:</strong> ${data.total_bookings}</p>
                <p><strong>Pending Bookings:</strong> ${data.pending_bookings}</p>
                <p><strong>Completed Bookings:</strong> ${data.completed_bookings}</p>
                <p><strong>Total Earnings:</strong> $${data.earnings}</p>
            `;
        });

    document.getElementById('logout').addEventListener('click', async () => {
        const response = await fetch('/api/partner/logout', { method: 'POST' });
        if (response.ok) {
            window.location.href = '/partner';
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const serviceCategorySelect = document.getElementById('service_category_id');

    // Fetch service categories for the dropdown
    fetch('/api/user/services')
        .then(response => response.json())
        .then(data => {
            data.forEach(service => {
                const option = document.createElement('option');
                option.value = service.id;
                option.textContent = service.name;
                serviceCategorySelect.appendChild(option);
            });
        });

    document.getElementById('partner-register-form').addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());

        const response = await fetch('/api/partner/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            alert(result.message);
            window.location.href = '/partner';
        } else {
            alert(result.message);
        }
    });
});

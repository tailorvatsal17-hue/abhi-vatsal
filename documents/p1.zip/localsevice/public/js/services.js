document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/user/services')
        .then(response => response.json())
        .then(data => {
            const serviceCategories = document.getElementById('service-categories');
            data.forEach(category => {
                const categoryDiv = document.createElement('div');
                categoryDiv.classList.add('service-category');
                categoryDiv.innerHTML = `
                    <h3>${category.name}</h3>
                    <p>${category.description}</p>
                    <a href="/providers?category=${category.id}">View Providers</a>
                `;
                serviceCategories.appendChild(categoryDiv);
            });
        });
});

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const categoryId = urlParams.get('category');

    fetch(`/api/user/providers/${categoryId}`)
        .then(response => response.json())
        .then(data => {
            const providersList = document.getElementById('providers-list');
            if (data.length === 0) {
                providersList.innerHTML = '<p>No providers found for this service.</p>';
                return;
            }
            data.forEach(provider => {
                const providerDiv = document.createElement('div');
                providerDiv.classList.add('provider');
                providerDiv.innerHTML = `
                    <h3>${provider.name}</h3>
                    <p>${provider.description}</p>
                    <p>Location: ${provider.location}</p>
                    <a href="/booking?provider=${provider.id}">Book Now</a>
                `;
                providersList.appendChild(providerDiv);
            });
        });
});

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const providerId = urlParams.get('provider');
    document.getElementById('provider-id').value = providerId;

    document.getElementById('booking-form').addEventListener('submit', async (e) => {
        e.preventDefault();

        const provider_id = document.getElementById('provider-id').value;
        const booking_time = document.getElementById('booking_time').value;
        const address = document.getElementById('address').value;

        const response = await fetch('/api/user/book', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ provider_id, booking_time, address })
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message);
            // Redirect to a confirmation page or profile page
            window.location.href = `/booking/confirmation?id=${data.booking_id}`;
        } else {
            alert(data.message);
        }
    });
});

const db = require('../config/db');
const bcrypt = require('bcryptjs');

const ServiceProvider = {
  create: async (name, email, password, phone, service_category_id, location, description) => {
    const hash = await bcrypt.hash(password, 10);
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO service_providers (name, email, password, phone, service_category_id, location, description) VALUES (?, ?, ?, ?, ?, ?, ?)';
      db.query(query, [name, email, hash, phone, service_category_id, location, description], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  findByEmail: (email) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM service_providers WHERE email = ?';
      db.query(query, [email], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  findById: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM service_providers WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  getAll: () => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT sp.*, sc.name as service_category_name FROM service_providers sp JOIN service_categories sc ON sp.service_category_id = sc.id';
      db.query(query, (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },

  approve: (id) => {
    return new Promise((resolve, reject) => {
      const query = "UPDATE service_providers SET status = 'approved' WHERE id = ?";
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  reject: (id) => {
    return new Promise((resolve, reject) => {
      const query = "UPDATE service_providers SET status = 'rejected' WHERE id = ?";
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  updateProfile: (id, name, phone, location, description, profile_image) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE service_providers SET name = ?, phone = ?, location = ?, description = ?, profile_image = ? WHERE id = ?';
      db.query(query, [name, phone, location, description, profile_image, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  updateStatus: (id, is_active) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE service_providers SET is_active = ? WHERE id = ?';
      db.query(query, [is_active, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

    getActiveProviders: () => {
        return new Promise((resolve, reject) => {
            const query = "SELECT sp.*, sc.name as service_category_name FROM service_providers sp JOIN service_categories sc ON sp.service_category_id = sc.id WHERE sp.status = 'approved' AND sp.is_active = 1";
            db.query(query, (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });
    },

    getPendingProviders: () => {
        return new Promise((resolve, reject) => {
            const query = "SELECT sp.*, sc.name as service_category_name FROM service_providers sp JOIN service_categories sc ON sp.service_category_id = sc.id WHERE sp.status = 'pending'";
            db.query(query, (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });
    }
};

module.exports = ServiceProvider;

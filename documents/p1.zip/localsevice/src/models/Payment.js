const db = require('../config/db');

const Payment = {
  create: (booking_id, amount) => {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO payments (booking_id, amount) VALUES (?, ?)';
      db.query(query, [booking_id, amount], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  findByBookingId: (booking_id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM payments WHERE booking_id = ?';
      db.query(query, [booking_id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  updateStatus: (id, payment_status) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE payments SET payment_status = ? WHERE id = ?';
      db.query(query, [payment_status, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

    getAll: () => {
        return new Promise((resolve, reject) => {
            const query = 'SELECT p.*, b.id as booking_id FROM payments p JOIN bookings b ON p.booking_id = b.id';
            db.query(query, (err, results) => {
                if (err) {
                    return reject(err);
                }
                resolve(results);
            });
        });
    }
};

module.exports = Payment;

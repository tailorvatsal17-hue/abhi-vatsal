const db = require('../config/db');

const Admin = {
  findByEmail: (email) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM admin WHERE email = ?';
      db.query(query, [email], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  }
};

module.exports = Admin;

const db = require('../config/db');

const Booking = {
  create: (user_id, provider_id, service_category_id, booking_time, address) => {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO bookings (user_id, provider_id, service_category_id, booking_time, address) VALUES (?, ?, ?, ?, ?)';
      db.query(query, [user_id, provider_id, service_category_id, booking_time, address], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  findByUserId: (user_id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT b.*, sp.name as provider_name, sc.name as service_category_name FROM bookings b JOIN service_providers sp ON b.provider_id = sp.id JOIN service_categories sc ON b.service_category_id = sc.id WHERE b.user_id = ?';
      db.query(query, [user_id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },

  findByProviderId: (provider_id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT b.*, u.name as user_name, sc.name as service_category_name FROM bookings b JOIN users u ON b.user_id = u.id JOIN service_categories sc ON b.service_category_id = sc.id WHERE b.provider_id = ?';
      db.query(query, [provider_id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },

  findById: (id) => {
    return new Promise((resolve, reject) => {
        const query = 'SELECT b.*, u.name as user_name, sp.name as provider_name, sc.name as service_category_name FROM bookings b JOIN users u ON b.user_id = u.id JOIN service_providers sp ON b.provider_id = sp.id JOIN service_categories sc ON b.service_category_id = sc.id WHERE b.id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  updateStatus: (id, status) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE bookings SET status = ? WHERE id = ?';
      db.query(query, [status, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  getAll: () => {
    return new Promise((resolve, reject) => {
        const query = 'SELECT b.*, u.name as user_name, sp.name as provider_name, sc.name as service_category_name FROM bookings b JOIN users u ON b.user_id = u.id JOIN service_providers sp ON b.provider_id = sp.id JOIN service_categories sc ON b.service_category_id = sc.id';
        db.query(query, (err, results) => {
            if (err) {
                return reject(err);
            }
            resolve(results);
        });
    });
  }
};

module.exports = Booking;

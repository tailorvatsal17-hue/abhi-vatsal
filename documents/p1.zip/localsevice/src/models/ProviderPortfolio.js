const db = require('../config/db');

const ProviderPortfolio = {
  create: (provider_id, image_url) => {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO provider_portfolio (provider_id, image_url) VALUES (?, ?)';
      db.query(query, [provider_id, image_url], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  findByProviderId: (provider_id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM provider_portfolio WHERE provider_id = ?';
      db.query(query, [provider_id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },

  delete: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM provider_portfolio WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  }
};

module.exports = ProviderPortfolio;

const db = require('../config/db');
const bcrypt = require('bcryptjs');

const User = {
  create: async (name, email, password) => {
    const hash = await bcrypt.hash(password, 10);
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
      db.query(query, [name, email, hash], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  findByEmail: (email) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM users WHERE email = ?';
      db.query(query, [email], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  findById: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM users WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  updateOtp: (id, otp) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE users SET otp = ? WHERE id = ?';
      db.query(query, [otp, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  verifyUser: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE users SET is_verified = 1, otp = NULL WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  blockUser: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE users SET is_blocked = 1 WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  unblockUser: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE users SET is_blocked = 0 WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  getAll: () => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT id, name, email, is_verified, is_blocked, created_at FROM users';
      db.query(query, (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  }
};

module.exports = User;

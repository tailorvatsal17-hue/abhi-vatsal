const db = require('../config/db');

const ProviderPricing = {
  create: (provider_id, service_name, price) => {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO provider_pricing (provider_id, service_name, price) VALUES (?, ?, ?)';
      db.query(query, [provider_id, service_name, price], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  findByProviderId: (provider_id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM provider_pricing WHERE provider_id = ?';
      db.query(query, [provider_id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },

  update: (id, service_name, price) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE provider_pricing SET service_name = ?, price = ? WHERE id = ?';
      db.query(query, [service_name, price, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  delete: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM provider_pricing WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  }
};

module.exports = ProviderPricing;

const db = require('../config/db');

const ServiceCategory = {
  create: (name, description, base_price) => {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO service_categories (name, description, base_price) VALUES (?, ?, ?)';
      db.query(query, [name, description, base_price], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.insertId);
      });
    });
  },

  getAll: () => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM service_categories';
      db.query(query, (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },

  findById: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM service_categories WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results[0]);
      });
    });
  },

  update: (id, name, description, base_price) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE service_categories SET name = ?, description = ?, base_price = ? WHERE id = ?';
      db.query(query, [name, description, base_price, id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  },

  delete: (id) => {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM service_categories WHERE id = ?';
      db.query(query, [id], (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results.affectedRows > 0);
      });
    });
  }
};

module.exports = ServiceCategory;

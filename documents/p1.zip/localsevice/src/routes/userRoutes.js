const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// User registration
router.post('/register', userController.register);

// Verify OTP
router.post('/verify-otp', userController.verifyOtp);

// User login
router.post('/login', userController.login);

// Get all services
router.get('/services', userController.getAllServices);

// Get service providers by category
router.get('/providers/:categoryId', userController.getProvidersByCategory);

// Search for services
router.get('/search', userController.searchServices);

// Book a service
router.post('/book', userController.bookService);

// Dummy payment
router.post('/payment', userController.dummyPayment);

// Get booking details
router.get('/booking/:bookingId', userController.getBookingDetails);

// Cancel a booking
router.put('/booking/cancel/:bookingId', userController.cancelBooking);

// Get user profile
router.get('/profile', userController.getProfile);

// Update user profile
router.put('/profile', userController.updateProfile);

// Get user bookings
router.get('/bookings', userController.getUserBookings);

// Logout
router.post('/logout', userController.logout);

module.exports = router;

const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
console.log(adminController);

// Admin login
router.post('/login', adminController.login);

// // Get dashboard data
// router.get('/dashboard', adminController.getDashboardData);

// // Get all users
// router.get('/users', adminController.getAllUsers);

// // Get user by id
// router.get('/users/:userId', adminController.getUserById);

// // Get user booking history
// router.get('/users/:userId/bookings', adminController.getUserBookings);

// // Block/unblock user
// router.put('/users/:userId/toggle-block', adminController.toggleUserBlock);

// // Get all service providers
// router.get('/providers', adminController.getAllProviders);

// // Get service provider by id
// router.get('/providers/:providerId', adminController.getProviderById);

// // Approve/reject service provider
// router.put('/providers/:providerId/approve', adminController.approveProvider);

// // Activate/deactivate service provider
// router.put('/providers/:providerId/toggle-active', adminController.toggleProviderActive);

// // Manage partner work details
// router.put('/providers/:providerId/work-details', adminController.manageWorkDetails);

// // Manage partner portfolio images
// router.post('/providers/:providerId/portfolio-images', adminController.addPortfolioImage);
// router.delete('/providers/:providerId/portfolio-images/:imageId', adminController.deletePortfolioImage);

// // Manage partner pricing
// router.post('/providers/:providerId/pricing', adminController.addPricing);
// router.put('/providers/:providerId/pricing/:pricingId', adminController.updatePricing);
// router.delete('/providers/:providerId/pricing/:pricingId', adminController.deletePricing);

// // Get all services
// router.get('/services', adminController.getAllServices);

// // Add a new service
// router.post('/services', adminController.addService);

// // Edit a service
// // router.put('/services/:serviceId', adminController.editService);

// // Delete a service
// router.delete('/services/:serviceId', adminController.deleteService);

// // Assign a service to a partner
// router.post('/services/assign', adminController.assignServiceToPartner);

// // Get all bookings
// router.get('/bookings', adminController.getAllBookings);

// // Update booking status
// router.put('/bookings/:bookingId/status', adminController.updateBookingStatus);

// // Get all payments
// router.get('/payments', adminController.getAllPayments);

// // Get commission report
// router.get('/commission', adminController.getCommissionReport);

// // Logout
// router.post('/logout', adminController.logout);

module.exports = router;

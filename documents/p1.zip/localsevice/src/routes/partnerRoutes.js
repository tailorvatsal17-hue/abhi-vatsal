const express = require('express');
const router = express.Router();
const partnerController = require('../controllers/partnerController');

// Partner registration
router.post('/register', partnerController.register);

// Partner login
router.post('/login', partnerController.login);

// Get dashboard data
router.get('/dashboard', partnerController.getDashboardData);

// Get booking requests
router.get('/bookings', partnerController.getBookingRequests);

// Accept/reject a booking
router.put('/bookings/:bookingId', partnerController.handleBookingRequest);

// Get partner profile
router.get('/profile', partnerController.getProfile);

// Update partner profile
router.put('/profile', partnerController.updateProfile);

// Add portfolio image
router.post('/portfolio-image', partnerController.addPortfolioImage);

// Delete portfolio image
router.delete('/portfolio-image/:imageId', partnerController.deletePortfolioImage);

// Add pricing
router.post('/pricing', partnerController.addPricing);

// Update pricing
router.put('/pricing/:pricingId', partnerController.updatePricing);

// Delete pricing
router.delete('/pricing/:pricingId', partnerController.deletePricing);

// Get portfolio
router.get('/portfolio', partnerController.getPortfolio);

// Get pricing
router.get('/pricing', partnerController.getPricing);

// Logout
router.post('/logout', partnerController.logout);

module.exports = router;

const User = require('../models/User');
const ServiceCategory = require('../models/ServiceCategory');
const ServiceProvider = require('../models/ServiceProvider');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const transporter = require('../config/email');
const otpGenerator = require('otp-generator');
const bcrypt = require('bcryptjs');

exports.register = async (req, res) => {
    const { name, email, password } = req.body;

    try {
        const existingUser = await User.findByEmail(email);
        if (existingUser) {
            return res.status(409).json({ message: 'You already have an account. Please login.' });
        }

        const otp = otpGenerator.generate(6, { upperCase: false, specialChars: false });
        const userId = await User.create(name, email, password);
        await User.updateOtp(userId, otp);

        const mailOptions = {
            from: 'your_email@gmail.com',
            to: email,
            subject: 'OTP for verification',
            text: `Your OTP is ${otp}`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Error sending email:', error);
                return res.status(500).json({ error: 'Error sending email' });
            }
            res.status(200).json({ message: 'OTP sent to your email' });
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.verifyOtp = async (req, res) => {
    const { email, otp } = req.body;

    try {
        const user = await User.findByEmail(email);
        if (!user || user.otp !== otp) {
            return res.status(400).json({ message: 'Invalid OTP' });
        }

        await User.verifyUser(user.id);
        res.status(200).json({ message: 'OTP verified successfully. Please login.' });
    } catch (error) {
        console.error('OTP verification error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findByEmail(email);
        if (!user) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        if (!user.is_verified) {
            return res.status(401).json({ message: 'Please verify your email first' });
        }

        req.session.user = user;
        res.status(200).json({ message: 'Logged in successfully' });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getAllServices = async (req, res) => {
    try {
        const services = await ServiceCategory.getAll();
        res.status(200).json(services);
    } catch (error) {
        console.error('Error getting all services:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getProvidersByCategory = async (req, res) => {
    const { categoryId } = req.params;
    try {
        const providers = await ServiceProvider.getActiveProviders();
        const providersByCategory = providers.filter(p => p.service_category_id === parseInt(categoryId));
        res.status(200).json(providersByCategory);
    } catch (error) {
        console.error('Error getting providers by category:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.searchServices = async (req, res) => {
    const { q } = req.query;
    try {
        const providers = await ServiceProvider.getActiveProviders();
        const lowercasedQuery = q.toLowerCase();
        const results = providers.filter(p => 
            p.name.toLowerCase().includes(lowercasedQuery) || 
            p.service_category_name.toLowerCase().includes(lowercasedQuery) ||
            p.location.toLowerCase().includes(lowercasedQuery)
        );
        res.status(200).json(results);
    } catch (error) {
        console.error('Error searching services:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.bookService = async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Please login to book a service' });
    }

    const { provider_id, booking_time, address } = req.body;
    const user_id = req.session.user.id;

    try {
        const provider = await ServiceProvider.findById(provider_id);
        if (!provider) {
            return res.status(404).json({ message: 'Service provider not found' });
        }

        const service_category_id = provider.service_category_id;
        const serviceCategory = await ServiceCategory.findById(service_category_id);
        if(!serviceCategory){
            return res.status(404).json({ message: 'Service category not found' });
        }

        const base_price = serviceCategory.base_price;
        const userBookings = await Booking.findByUserId(user_id);
        
        let handling_fee = 0;
        if (userBookings.length > 0) {
            handling_fee = base_price * 0.05;
        }
        const tax = base_price * 0.02;
        const total_cost = base_price + handling_fee + tax;

        const booking_id = await Booking.create(user_id, provider_id, service_category_id, booking_time, address);
        await Payment.create(booking_id, total_cost);

        res.status(200).json({ message: 'Booking successful', booking_id, total_cost });
    } catch (error) {
        console.error('Error booking service:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.dummyPayment = async (req, res) => {
    const { booking_id } = req.body;
    try {
        const payment = await Payment.findByBookingId(booking_id);
        if(!payment){
            return res.status(404).json({ message: 'Payment not found for this booking' });
        }
        await Payment.updateStatus(payment.id, 'paid');
        res.status(200).json({ message: 'Payment successful' });
    } catch (error) {
        console.error('Dummy payment error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getBookingDetails = async (req, res) => {
    const { bookingId } = req.params;
    try {
        const bookingDetails = await Booking.findById(bookingId);
        if (!bookingDetails) {
            return res.status(404).json({ message: 'Booking not found' });
        }
        const payment = await Payment.findByBookingId(bookingId);
        bookingDetails.payment_status = payment ? payment.payment_status : 'not_paid';
        bookingDetails.amount = payment ? payment.amount : 0;
        res.status(200).json(bookingDetails);
    } catch (error) {
        console.error('Error getting booking details:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.cancelBooking = async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Please login to cancel a booking' });
    }

    const { bookingId } = req.params;
    const user_id = req.session.user.id;

    try {
        const booking = await Booking.findById(bookingId);
        if (!booking || booking.user_id !== user_id) {
            return res.status(404).json({ message: 'Booking not found or you are not authorized to cancel this booking' });
        }

        const bookingTime = new Date(booking.booking_time);
        const currentTime = new Date();

        if (bookingTime < currentTime) {
            return res.status(400).json({ message: 'You cannot cancel a booking that has already started' });
        }

        await Booking.updateStatus(bookingId, 'cancelled');
        res.status(200).json({ message: 'Booking cancelled successfully' });
    } catch (error) {
        console.error('Error cancelling booking:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getProfile = async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Please login to view your profile' });
    }

    const user_id = req.session.user.id;

    try {
        const user = await User.findById(user_id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        const {id, name, email} = user;
        res.status(200).json({id, name, email});
    } catch (error) {
        console.error('Error getting profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.updateProfile = async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Please login to update your profile' });
    }

    const user_id = req.session.user.id;
    const { name, password } = req.body;

    try {
        const hash = password ? await bcrypt.hash(password, 10) : undefined;
        // This is a simplified update. A more robust implementation would separate password updates.
        // For now, we'll just update the name and password if a new password is provided.
        const user = await User.findById(user_id);
        
        let query = 'UPDATE users SET name = ?';
        const params = [name];

        if (hash) {
            query += ', password = ?';
            params.push(hash);
        }

        query += ' WHERE id = ?';
        params.push(user_id);

        const db = require('../config/db');
        db.query(query, params, (err, results) => {
            if(err){
                return res.status(500).json({ error: 'Internal server error' });
            }
            res.status(200).json({ message: 'Profile updated successfully' });
        });

    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};


exports.getUserBookings = async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Please login to view your bookings' });
    }

    const user_id = req.session.user.id;

    try {
        const bookings = await Booking.findByUserId(user_id);
        res.status(200).json(bookings);
    } catch (error) {
        console.error('Error getting user bookings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.logout = (req, res) => {
    req.session.destroy();
    res.status(200).json({ message: 'Logged out successfully' });
};

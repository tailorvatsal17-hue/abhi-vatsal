const Admin = require('../models/Admin');
const User = require('../models/User');
const ServiceProvider = require('../models/ServiceProvider');
const ServiceCategory = require('../models/ServiceCategory');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const ProviderPortfolio = require('../models/ProviderPortfolio');
const ProviderPricing = require('../models/ProviderPricing');
const bcrypt = require('bcryptjs');

exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const admin = await Admin.findByEmail(email);
        if (!admin) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        // Note: The database schema doesn't specify a hashed password for admin. 
        // For production, you should hash the admin password.
        // For now, we'll do a plain text comparison as per the original code.
        const isMatch = admin.password === password;

        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        req.session.admin = admin;
        res.status(200).json({ message: 'Logged in successfully' });
    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getDashboardData = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view the dashboard' });
    }

    try {
        const [users, providers, categories, bookings, payments] = await Promise.all([
            User.getAll(),
            ServiceProvider.getAll(),
            ServiceCategory.getAll(),
            Booking.getAll(),
            Payment.getAll()
        ]);

        const total_users = users.length;
        const total_service_partners = providers.length;
        const total_services = categories.length;
        const total_bookings = bookings.length;
        const total_earnings = payments
            .filter(p => p.payment_status === 'paid')
            .reduce((sum, p) => sum + parseFloat(p.amount), 0);

        const booking_status = bookings.reduce((acc, booking) => {
            acc[booking.status] = (acc[booking.status] || 0) + 1;
            return acc;
        }, {});


        res.status(200).json({
            total_users,
            total_service_partners,
            total_services,
            total_bookings,
            total_earnings,
            booking_status
        });
    } catch (error) {
        console.error('Error getting dashboard data:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getAllUsers = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view users' });
    }

    try {
        const users = await User.getAll();
        res.status(200).json(users);
    } catch (error) {
        console.error('Error getting all users:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getUserById = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view users' });
    }

    const { userId } = req.params;

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.status(200).json(user);
    } catch (error) {
        console.error('Error getting user by ID:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getUserBookings = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view user bookings' });
    }

    const { userId } = req.params;

    try {
        const bookings = await Booking.findByUserId(userId);
        res.status(200).json(bookings);
    } catch (error) {
        console.error('Error getting user bookings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.toggleUserBlock = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to block/unblock users' });
    }

    const { userId } = req.params;

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const is_blocked = !user.is_blocked;
        if(is_blocked){
            await User.blockUser(userId);
        } else {
            await User.unblockUser(userId);
        }
        
        res.status(200).json({ message: `User ${is_blocked ? 'blocked' : 'unblocked'} successfully` });
    } catch (error) {
        console.error('Error toggling user block status:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getAllProviders = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view service providers' });
    }

    try {
        const providers = await ServiceProvider.getAll();
        res.status(200).json(providers);
    } catch (error) {
        console.error('Error getting all providers:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getProviderById = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view service providers' });
    }

    const { providerId } = req.params;

    try {
        const provider = await ServiceProvider.findById(providerId);
        if (!provider) {
            return res.status(404).json({ message: 'Service provider not found' });
        }
        res.status(200).json(provider);
    } catch (error) {
        console.error('Error getting provider by ID:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.approveProvider = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to approve service providers' });
    }

    const { providerId } = req.params;
    const { status } = req.body; // status can be 'approved' or 'rejected'

    try {
        if(status === 'approved'){
            await ServiceProvider.approve(providerId);
        } else if (status === 'rejected') {
            await ServiceProvider.reject(providerId);
        } else {
            return res.status(400).json({ message: 'Invalid status' });
        }
        res.status(200).json({ message: `Service provider has been ${status}` });
    } catch (error) {
        console.error('Error approving provider:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.toggleProviderActive = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to activate/deactivate service providers' });
    }

    const { providerId } = req.params;

    try {
        const provider = await ServiceProvider.findById(providerId);
        if (!provider) {
            return res.status(404).json({ message: 'Service provider not found' });
        }

        const is_active = !provider.is_active;
        await ServiceProvider.updateStatus(providerId, is_active);

        res.status(200).json({ message: `Service provider has been ${is_active ? 'activated' : 'deactivated'}` });
    } catch (error) {
        console.error('Error toggling provider active status:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.addService = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to add services' });
    }

    const { name, description, base_price } = req.body;

    try {
        await ServiceCategory.create(name, description, base_price);
        res.status(200).json({ message: 'Service added successfully' });
    } catch (error) {
        console.error('Error adding service:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.editService = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to edit services' });
    }

    const { serviceId } = req.params;
    const { name, description, base_price } = req.body;

    try {
        await ServiceCategory.update(serviceId, name, description, base_price);
        res.status(200).json({ message: 'Service updated successfully' });
    } catch (error) {
        console.error('Error editing service:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.deleteService = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to delete services' });
    }

    const { serviceId } = req.params;

    try {
        await ServiceCategory.delete(serviceId);
        res.status(200).json({ message: 'Service deleted successfully' });
    } catch (error) {
        console.error('Error deleting service:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getAllBookings = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view bookings' });
    }
    
    try {
        const bookings = await Booking.getAll();
        res.status(200).json(bookings);
    } catch (error) {
        console.error('Error getting all bookings:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.updateBookingStatus = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to update booking status' });
    }

    const { bookingId } = req.params;
    const { status } = req.body;

    try {
        await Booking.updateStatus(bookingId, status);
        res.status(200).json({ message: 'Booking status updated successfully' });
    } catch (error) {
        console.error('Error updating booking status:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getAllPayments = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view payments' });
    }

    try {
        const payments = await Payment.getAll();
        res.status(200).json(payments);
    } catch (error) {
        console.error('Error getting all payments:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getCommissionReport = async (req, res) => {
    if (!req.session.admin) {
        return res.status(401).json({ message: 'Please login to view commission report' });
    }

    try {
        const payments = await Payment.getAll();
        const paidPayments = payments.filter(p => p.payment_status === 'paid');

        const total_commission = paidPayments.reduce((sum, p) => sum + parseFloat(p.commission), 0);

        const commission_per_booking = paidPayments.map(p => ({
            booking_id: p.booking_id,
            commission: p.commission
        }));

        res.status(200).json({
            total_commission,
            commission_per_booking
        });
    } catch (error) {
        console.error('Error getting commission report:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.logout = (req, res) => {
    req.session.destroy();
    res.status(200).json({ message: 'Logged out successfully' });
};


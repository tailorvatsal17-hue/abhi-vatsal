const ServiceProvider = require('../models/ServiceProvider');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const ProviderPortfolio = require('../models/ProviderPortfolio');
const ProviderPricing = require('../models/ProviderPricing');
const User = require('../models/User');
const transporter = require('../config/email');
const bcrypt = require('bcryptjs');

exports.register = async (req, res) => {
    const { name, email, password, phone, service_category_id, location, description } = req.body;

    try {
        const existingProvider = await ServiceProvider.findByEmail(email);
        if (existingProvider) {
            return res.status(409).json({ message: 'You already have an account. Please login.' });
        }

        await ServiceProvider.create(name, email, password, phone, service_category_id, location, description);
        res.status(200).json({ message: 'Registration successful. Your account is pending approval.' });
    } catch (error) {
        console.error('Partner registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const partner = await ServiceProvider.findByEmail(email);
        if (!partner) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, partner.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        if (partner.status !== 'approved') {
            return res.status(401).json({ message: 'Your account is not approved yet.' });
        }

        req.session.partner = partner;
        res.status(200).json({ message: 'Logged in successfully' });
    } catch (error) {
        console.error('Partner login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getDashboardData = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to view the dashboard' });
    }

    const partner_id = req.session.partner.id;

    try {
        const bookings = await Booking.findByProviderId(partner_id);
        const payments = await Payment.getAll();

        const total_bookings = bookings.length;
        const pending_bookings = bookings.filter(b => b.status === 'pending').length;
        const completed_bookings = bookings.filter(b => b.status === 'completed').length;
        
        const providerBookingIds = bookings.map(b => b.id);
        const earnings = payments
            .filter(p => providerBookingIds.includes(p.booking_id) && p.payment_status === 'paid')
            .reduce((sum, p) => sum + parseFloat(p.amount), 0);

        res.status(200).json({
            total_bookings,
            pending_bookings,
            completed_bookings,
            earnings
        });
    } catch (error) {
        console.error('Error getting dashboard data:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getBookingRequests = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to view booking requests' });
    }

    const partner_id = req.session.partner.id;

    try {
        const bookings = await Booking.findByProviderId(partner_id);
        res.status(200).json(bookings);
    } catch (error) {
        console.error('Error getting booking requests:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.handleBookingRequest = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to handle booking requests' });
    }

    const { bookingId } = req.params;
    const { action } = req.body; // 'accept' or 'reject'
    const partner_id = req.session.partner.id;

    let newStatus = '';
    if (action === 'accept') {
        newStatus = 'confirmed';
    } else if (action === 'reject') {
        newStatus = 'cancelled';
    } else {
        return res.status(400).json({ message: 'Invalid action' });
    }

    try {
        const booking = await Booking.findById(bookingId);
        if (!booking || booking.provider_id !== partner_id) {
            return res.status(404).json({ message: 'Booking not found or you are not authorized to handle this booking' });
        }

        await Booking.updateStatus(bookingId, newStatus);

        if (newStatus === 'confirmed') {
            const customer = await User.findById(booking.user_id);
            const partner = req.session.partner;

            const customerMailOptions = {
                from: 'your_email@gmail.com',
                to: customer.email,
                subject: 'Booking Confirmed',
                text: `Your booking for ${booking.service_category_name} on ${booking.booking_time} has been confirmed.`
            };

            const partnerMailOptions = {
                from: 'your_email@gmail.com',
                to: partner.email,
                subject: 'Booking Confirmed',
                text: `You have a new booking for ${booking.service_category_name} on ${booking.booking_time}.`
            };
            
            transporter.sendMail(customerMailOptions);
            transporter.sendMail(partnerMailOptions);
        }

        res.status(200).json({ message: `Booking ${newStatus}` });
    } catch (error) {
        console.error('Error handling booking request:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getProfile = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to view your profile' });
    }

    const partner_id = req.session.partner.id;

    try {
        const partner = await ServiceProvider.findById(partner_id);
        if (!partner) {
            return res.status(404).json({ message: 'Partner not found' });
        }
        const { name, email, phone, location, description, profile_image } = partner;
        res.status(200).json({ name, email, phone, location, description, profile_image });
    } catch (error) {
        console.error('Error getting profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.updateProfile = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to update your profile' });
    }

    const partner_id = req.session.partner.id;
    const { name, phone, location, description, profile_image, password } = req.body;

    try {
        let hash;
        if(password){
            hash = await bcrypt.hash(password, 10);
        }
        //This is a simplified approach. In a real app, you might want a more robust way to build the update query.
        const db = require('../config/db');
        let query = 'UPDATE service_providers SET ';
        const params = [];
        if(name) {
            query += 'name = ?, ';
            params.push(name);
        }
        if(phone) {
            query += 'phone = ?, ';
            params.push(phone);
        }
        if(location) {
            query += 'location = ?, ';
            params.push(location);
        }
        if(description) {
            query += 'description = ?, ';
            params.push(description);
        }
        if(profile_image) {
            query += 'profile_image = ?, ';
            params.push(profile_image);
        }
        if(hash) {
            query += 'password = ?, ';
            params.push(hash);
        }
        query = query.slice(0, -2); // remove trailing comma and space
        query += ' WHERE id = ?';
        params.push(partner_id);

        db.query(query, params, (err, result) => {
            if(err){
                return res.status(500).json({ error: 'Internal server error' });
            }
            res.status(200).json({ message: 'Profile updated successfully' });
        });

    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.addPortfolioImage = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to add portfolio images' });
    }

    const partner_id = req.session.partner.id;
    const { image_url } = req.body;

    try {
        await ProviderPortfolio.create(partner_id, image_url);
        res.status(200).json({ message: 'Portfolio image added successfully' });
    } catch (error) {
        console.error('Error adding portfolio image:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.deletePortfolioImage = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to delete portfolio images' });
    }

    const { imageId } = req.params;
    const partner_id = req.session.partner.id;

    try {
        const image = await ProviderPortfolio.delete(imageId, partner_id);
        if (image.affectedRows === 0) {
            return res.status(404).json({ message: 'Image not found or you are not authorized to delete it.' });
        }
        res.status(200).json({ message: 'Portfolio image deleted successfully' });
    } catch (error) {
        console.error('Error deleting portfolio image:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.addPricing = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to add pricing' });
    }

    const partner_id = req.session.partner.id;
    const { service_name, price } = req.body;

    try {
        await ProviderPricing.create(partner_id, service_name, price);
        res.status(200).json({ message: 'Pricing added successfully' });
    } catch (error) {
        console.error('Error adding pricing:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.updatePricing = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to update pricing' });
    }

    const { pricingId } = req.params;
    const partner_id = req.session.partner.id;
    const { service_name, price } = req.body;

    try {
        const pricing = await ProviderPricing.update(pricingId, service_name, price);
         if (pricing.affectedRows === 0) {
            return res.status(404).json({ message: 'Pricing not found or you are not authorized to update it.' });
        }
        res.status(200).json({ message: 'Pricing updated successfully' });
    } catch (error) {
        console.error('Error updating pricing:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.deletePricing = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to delete pricing' });
    }

    const { pricingId } = req.params;
    const partner_id = req.session.partner.id;

    try {
         const pricing = await ProviderPricing.delete(pricingId, partner_id);
         if (pricing.affectedRows === 0) {
            return res.status(404).json({ message: 'Pricing not found or you are not authorized to delete it.' });
        }
        res.status(200).json({ message: 'Pricing deleted successfully' });
    } catch (error) {
        console.error('Error deleting pricing:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getPortfolio = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to view your portfolio' });
    }

    const partner_id = req.session.partner.id;

    try {
        const portfolio = await ProviderPortfolio.findByProviderId(partner_id);
        res.status(200).json(portfolio);
    } catch (error) {
        console.error('Error getting portfolio:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.getPricing = async (req, res) => {
    if (!req.session.partner) {
        return res.status(401).json({ message: 'Please login to view your pricing' });
    }

    const partner_id = req.session.partner.id;

    try {
        const pricing = await ProviderPricing.findByProviderId(partner_id);
        res.status(200).json(pricing);
    } catch (error) {
        console.error('Error getting pricing:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

exports.logout = (req, res) => {
    req.session.destroy();
    res.status(200).json({ message: 'Logged out successfully' });
};

const nodemailer = require('nodemailer');

// Nodemailer configuration - TODO: Add your own email credentials
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'your_email@gmail.com',
        pass: 'your_password'
    }
});

module.exports = transporter;
